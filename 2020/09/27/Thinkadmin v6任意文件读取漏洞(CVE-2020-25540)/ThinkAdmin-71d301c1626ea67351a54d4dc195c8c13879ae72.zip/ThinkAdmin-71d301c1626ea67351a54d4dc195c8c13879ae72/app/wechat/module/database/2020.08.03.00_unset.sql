DROP TABLE IF EXISTS `_PREFIX_wechat_fans`;
DROP TABLE IF EXISTS `_PREFIX_wechat_fans_tags`;
DROP TABLE IF EXISTS `_PREFIX_wechat_keys`;
DROP TABLE IF EXISTS `_PREFIX_wechat_media`;
DROP TABLE IF EXISTS `_PREFIX_wechat_news`;
DROP TABLE IF EXISTS `_PREFIX_wechat_news_article`;